//
//  ImmersiveView.swift
//  Jenga
//
//  Created by Donovan Hutchinson on 26/06/2024.
//

import SwiftUI

import SwiftUI
import RealityKit
import RealityKitContent

struct ImmersiveView: View {
    @ObservedObject var viewModel: SharedViewModel

    var body: some View {
        RealityView { content in
            let floor = viewModel.generateFloor()
            content.add(floor)

            if let table = loadScene() {
                table.position.x = viewModel.startingPositionX + viewModel.pieceWidth
                table.position.y = viewModel.startingPositionY
                table.position.z = viewModel.startingPositionZ - viewModel.pieceWidth
           
                content.add(table)
            }
            
            // Add pieces
            content.add(viewModel.tower)
        } update: { content in

        }
        .installGestures()
    }
    
    private func loadScene() -> Entity? {
      try? Entity.load(named: "Scene", in: realityKitContentBundle)
    }
}

#Preview {
    ImmersiveView(viewModel: SharedViewModel())
}
