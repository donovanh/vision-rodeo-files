//
//  ContentView.swift
//  Jenga
//
//  Created by Donovan Hutchinson on 26/06/2024.
//

import SwiftUI
import RealityKit
import RealityKitContent

struct ContentView: View {
    @ObservedObject var viewModel: SharedViewModel
    
    @Environment(\.openImmersiveSpace) var openImmersiveSpace
    @Environment(\.dismissImmersiveSpace) var dismissImmersiveSpace
    
    var body: some View {
        VStack {
            Text("Jenga")
                .font(.extraLargeTitle)
            Button("Reset game") {
                viewModel.reset()
            }
        }
        .padding()
        .task {
            await openImmersiveSpace(id: "ImmersiveSpace")
        }
    }
}

#Preview(windowStyle: .automatic) {
    ContentView(viewModel: SharedViewModel())
}
