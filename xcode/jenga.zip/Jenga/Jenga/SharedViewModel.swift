//
//  SharedViewModel.swift
//  Jenga
//
//  Created by Donovan Hutchinson on 26/06/2024.
//

import Foundation
import RealityKit
import RealityKitContent
import SwiftUI

final class SharedViewModel: ObservableObject {
    
    let numberOfRows = 16
    let pieceWidth: Float = 0.075
    let pieceHeight: Float = 0.045
    let pieceDepth: Float = 0.225
    let startingPositionX: Float = -0.5
    let startingPositionY: Float = 0.75
    let startingPositionZ: Float = -1.75
    var tower = Entity()
    var pieceMaterial: RealityKit.Material?

    init() {
        pieceMaterial = loadPieceMaterial()
        generateTower()
    }
    
    func reset() {
        var i = 0
        for child in tower.children {
            if let modelEntity = child as? ModelEntity {
                child.orientation = simd_quatf()
                positionPiece(index: i, piece: modelEntity)
                i += 1
            }
        }
    }
    
    func positionPiece(index: Int, piece: ModelEntity) {
        let rowIndex = index / 3
        let pieceIndexInRow = index % 3
        
        if rowIndex % 2 == 0 {
            piece.position.x = Float(pieceIndexInRow) * pieceWidth
            piece.position.z = 0
        } else {
            // Odd row: align along z-axis
            piece.position.x = pieceWidth
            piece.position.z = (Float(pieceIndexInRow) * pieceWidth) - pieceWidth
            piece.orientation = simd_quatf(angle: .pi / 2, axis: SIMD3<Float>(0, 1, 0)) // Rotate 90 degrees around the y-axis
        }
        
        piece.position.y = (Float(rowIndex) * pieceHeight) - pieceHeight
    }
    
    func generateTower() {
        let numberOfPieces = numberOfRows * 3
        tower.position.x = startingPositionX
        tower.position.y = startingPositionY
        tower.position.z = startingPositionZ
        
        for i in 0..<numberOfPieces {
            let piece = generatePiece()
            piece.name = "piece-\(i + 1)"
            
            positionPiece(index: i, piece: piece)
            tower.addChild(piece)
        }
        tower.transform.rotation = simd_quatf(angle: .pi / 4, axis: SIMD3<Float>(0, 1, 0)) // Rotate 45 degrees around the y-axis
    }
    
    func generatePiece() -> ModelEntity {
        
        let piece: ModelEntity
        if let material = pieceMaterial {
            piece = ModelEntity(
                mesh: .generateBox(width: pieceWidth, height: pieceHeight, depth: pieceDepth, cornerRadius: 0.005),
                materials: [material]
            )
        } else {
            var defaultMaterial = PhysicallyBasedMaterial()
            defaultMaterial.baseColor.tint = .orange
            defaultMaterial.roughness = PhysicallyBasedMaterial.Roughness(floatLiteral: 1)
            
            piece = ModelEntity(
                mesh: .generateBox(width: pieceWidth, height: pieceHeight, depth: pieceDepth, cornerRadius: 0.005),
                materials: [defaultMaterial]
            )
        }

        // Shadow
        piece.components.set(GroundingShadowComponent(castsShadow: true))
        
        // Input
        piece.components.set(InputTargetComponent())
        
        // Hover effect
        piece.components.set(HoverEffectComponent())
        
        // Configure and apply gestures component
        let jsonData = """
        {
            "canDrag": true,
            "pivotOnDrag": true,
            "preserveOrientationOnPivotDrag": true,
            "canScale": false,
            "canRotate": true
        }
        """.data(using: .utf8)!
        
        do {
            let decoder = JSONDecoder()
            let gestureComponent = try decoder.decode(GestureComponent.self, from: jsonData)
            piece.components.set(gestureComponent)
        } catch {
            print("Failed to decode JSON: \(error)")
        }
        
        // Collisions
        piece.generateCollisionShapes(recursive: false)
        
        // Physics
        let physicsMaterial = PhysicsMaterialResource.generate(
            staticFriction: 0.35,
            dynamicFriction: 0.25,
            restitution: 0.5
        )
        piece.components[PhysicsBodyComponent.self] = .init(
            massProperties: .init(shape: .generateBox(width: pieceWidth, height: pieceHeight, depth: pieceDepth), mass: 1),
            material: physicsMaterial,
            mode: .dynamic
        )
        return piece
    }
    
    func loadPieceMaterial() -> RealityKit.Material? {
        guard let scene = try? Entity.load(named: "Scene", in: realityKitContentBundle) else {
            print("Error: Unable to load the scene.")
            return nil
        }
        
        func findMaterial(from entity: Entity) -> RealityKit.Material? {
            if let modelComponent = entity.components[ModelComponent.self] {
                return modelComponent.materials.first
            }
            
            for child in entity.children {
                if let material = findMaterial(from: child) {
                    return material
                }
            }

            return nil
        }
        
        func findEntity(named name: String, in entity: Entity) -> Entity? {
            if entity.name == name {
                return entity
            }
            
            for child in entity.children {
                if let foundEntity = findEntity(named: name, in: child) {
                    return foundEntity
                }
            }
            
            return nil
        }
        
        if let sphereEntity = findEntity(named: "PieceTexture", in: scene),
           let material = findMaterial(from: sphereEntity) {
            return material
        } else {
            print("Error: Unable to find 'Sphere' object or its material in the scene.")
            return nil
        }
    }
    
    func generateFloor() -> ModelEntity {
        let floor = ModelEntity(
            mesh: .generatePlane(width: 50, depth: 50),
            materials: [OcclusionMaterial()]
        )
        floor.generateCollisionShapes(recursive: false)
        floor.components[PhysicsBodyComponent.self] = .init(
            massProperties: .default,
            mode: .static
        )
        return floor
    }
    
}
